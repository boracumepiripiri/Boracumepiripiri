'use strict';

/* ── DADOS (idênticos ao original do Replit) ── */
const TAMANHOS = [
  { id: 'p', name: 'Tamanho P', price: 'R$ 12,00', value: 12 },
  { id: 'm', name: 'Tamanho M', price: 'R$ 15,00', value: 15 },
  { id: 'g', name: 'Tamanho G', price: 'R$ 17,00', value: 17 },
];
const MACARROES = [
  { id: 'espaguete', name: 'Macarrão Espaguete', desc: 'O clássico longo' },
  { id: 'penne',     name: 'Macarrão Penne',     desc: 'Tubinhos perfeitos' },
];
const MOLHOS = [
  { id: 'branco_cremoso', name: 'Molho Branco Cremoso', desc: 'Cremoso e suave' },
  { id: 'bolonhesa',      name: 'Molho à Bolonhesa',    desc: 'Tradicional com carne' },
];
const PROTEINAS = [
  { id: 'frango_desfiado', name: 'Frango Desfiado' },
  { id: 'bacon',           name: 'Bacon' },
  { id: 'calabresa',       name: 'Calabresa' },
  { id: 'camarao',         name: 'Camarão' },
];
const ADICIONAIS = [
  { id: 'batata_palha',  name: 'Batata Palha' },
  { id: 'presunto',      name: 'Presunto' },
  { id: 'queijo_extra',  name: 'Queijo Extra' },
  { id: 'milho_verde',   name: 'Milho Verde' },
  { id: 'azeitona',      name: 'Azeitona' },
  { id: 'ervilha',       name: 'Ervilha' },
];
const CALDOS = [
  { id: 'caldo_macaxeira', name: 'Caldo de Macaxeira', ingredientes: 'Calabresa, cheiro verde e adicionais', price: 'R$ 15,00', value: 15 },
];
const BEBIDAS = [
  { id: 'coca_350', name: 'Coca-Cola 350ml', price: 'R$ 6,00', value: 6 },
];
const PAGAMENTOS = [
  { id: 'pix',      name: 'Pix' },
  { id: 'dinheiro', name: 'Dinheiro' },
  { id: 'cartao',   name: 'Cartão' },
];
const TAXA_DELIVERY = 5;

/* ── ESTADO ── */
const S = {
  nome: '', tamanho: null, macarrao: null, molho: null,
  proteinas: [], adicionais: [], caldos: [], bebidas: [],
  observacoes: '', pagamento: null, entrega: null,
  bairro: '', rua: '', numero: '', referencia: '',
};

/* ── HELPERS ── */
const fmt = n => `R$ ${n.toFixed(2).replace('.', ',')}`;

function calcTotal() {
  const t       = TAMANHOS.find(x => x.id === S.tamanho);
  const base    = (S.macarrao && t) ? t.value : 0;
  const extras  = Math.max(0, S.proteinas.length - 1) * 5;
  const caldosV = S.caldos.reduce((s, id)  => s + (CALDOS.find(c => c.id === id)?.value  || 0), 0);
  const bebidasV= S.bebidas.reduce((s, id) => s + (BEBIDAS.find(b => b.id === id)?.value || 0), 0);
  const delivery= S.entrega === 'delivery' ? TAXA_DELIVERY : 0;
  return { base, extras, caldosV, bebidasV, delivery, total: base + extras + caldosV + bebidasV + delivery };
}

function canSubmit() {
  const orderingPasta = S.tamanho || S.macarrao || S.molho;
  const pastaOk  = !orderingPasta || (S.tamanho && S.macarrao && S.molho);
  const hasItems = (S.tamanho && S.macarrao && S.molho) || S.caldos.length > 0 || S.bebidas.length > 0;
  const endOk    = S.entrega === 'retirada' ||
    (S.entrega === 'delivery' && S.bairro.trim() && S.rua.trim() && S.numero.trim());
  return S.nome.trim() !== '' && hasItems && pastaOk && S.pagamento && S.entrega && endOk;
}

function buildMessage() {
  const t   = TAMANHOS.find(x => x.id === S.tamanho);
  const mac = MACARROES.find(x => x.id === S.macarrao)?.name;
  const mol = MOLHOS.find(x => x.id === S.molho)?.name;
  const prot= S.proteinas.map(id => PROTEINAS.find(x => x.id === id)?.name).join(', ');
  const adic= S.adicionais.map(id => ADICIONAIS.find(x => x.id === id)?.name).join(', ');
  const extras = Math.max(0, S.proteinas.length - 1);
  const { extras: extraVal, caldosV, bebidasV, total } = calcTotal();
  const pg  = PAGAMENTOS.find(x => x.id === S.pagamento)?.name;

  let txt = `Olá, BoraCumê! Gostaria de fazer um pedido:\n\n`;
  txt += `🍝 *Nome:* ${S.nome.trim()}\n`;
  if (S.macarrao) {
    if (t)   txt += `🍝 *Tamanho:* ${t.name} - ${t.price}\n`;
    if (mac) txt += `🍝 *Massa:* ${mac}\n`;
    if (mol) txt += `🍝 *Molho:* ${mol}\n`;
    if (prot) {
      txt += `🍝 *Proteínas:* ${prot}`;
      if (extras > 0) txt += ` (+ ${fmt(extraVal)} por ${extras} proteína${extras > 1 ? 's' : ''} extra${extras > 1 ? 's' : ''})`;
      txt += `\n`;
    }
    if (adic) txt += `🍝 *Adicionais:* ${adic}\n`;
  }
  if (S.caldos.length)  txt += `🍝 *Caldos:* ${S.caldos.map(id => CALDOS.find(x => x.id === id)?.name).join(', ')}\n`;
  if (S.bebidas.length) txt += `🍝 *Bebidas:* ${S.bebidas.map(id => BEBIDAS.find(x => x.id === id)?.name).join(', ')}\n`;
  if (pg) txt += `🍝 *Pagamento:* ${pg}\n`;
  if (S.observacoes.trim()) txt += `🍝 *Observações:* ${S.observacoes.trim()}\n`;

  if (S.entrega === 'retirada') {
    txt += `\n🍝 *Retirada no local:*\nPlanalto Petecas, Quadra W1, Casa 11\n`;
  } else if (S.entrega === 'delivery') {
    txt += `\n🍝 *Entrega (Delivery):*\nBairro: ${S.bairro}\nRua: ${S.rua}\nNúmero: ${S.numero}\n`;
    if (S.referencia.trim()) txt += `Referência: ${S.referencia}\n`;
    txt += `Taxa de entrega: ${fmt(TAXA_DELIVERY)}\n`;
  }
  txt += `\n🍝 *Total: ${fmt(total)}*`;
  return encodeURIComponent(txt);
}

/* ── RENDER ── */
function render() {
  /* Números dos passos ativos */
  const act = (id, cond) => document.getElementById(id)?.classList.toggle('active', cond);
  act('sn1',  S.nome.trim() !== '');
  act('sn2',  !!S.tamanho);
  act('sn3',  !!S.macarrao);
  act('sn4',  !!S.molho);
  act('sn7',  S.caldos.length > 0);
  act('sn8',  S.bebidas.length > 0);
  act('sn10', !!S.pagamento);
  act('sn11', !!S.entrega);

  const hasAny = S.nome || S.tamanho || S.macarrao || S.molho ||
    S.proteinas.length || S.adicionais.length || S.caldos.length ||
    S.bebidas.length || S.pagamento || S.entrega;

  /* Empty state */
  const emptyEl = document.getElementById('summary-empty');
  if (emptyEl) emptyEl.classList.toggle('hidden', !!hasAny);

  /* Items */
  const itemsEl = document.getElementById('summary-items');
  const totalsEl= document.getElementById('summary-totals');
  const sepEl   = document.getElementById('summary-sep');
  const actEl   = document.getElementById('summary-action');
  if (!itemsEl) return;

  /* Build groups */
  const groups = [];
  if (S.nome.trim()) groups.push({ label: 'Nome', value: S.nome.trim() });
  const t = TAMANHOS.find(x => x.id === S.tamanho);
  if (t && S.macarrao) groups.push({ label: 'Tamanho', value: `${t.name}<span class="price">${t.price}</span>` });
  const mac = MACARROES.find(x => x.id === S.macarrao);
  if (mac) groups.push({ label: 'Massa', value: mac.name });
  const mol = MOLHOS.find(x => x.id === S.molho);
  if (mol) groups.push({ label: 'Molho', value: mol.name });
  if (S.proteinas.length) groups.push({ label: 'Proteínas', value: S.proteinas.map(id => PROTEINAS.find(x => x.id === id)?.name).join(', ') });
  if (S.adicionais.length) groups.push({ label: 'Adicionais', value: S.adicionais.map(id => ADICIONAIS.find(x => x.id === id)?.name).join(', ') });
  S.caldos.forEach(id => {
    const c = CALDOS.find(x => x.id === id);
    if (c) groups.push({ label: 'Caldo', value: `${c.name} — <span class="price">${c.price}</span>` });
  });
  S.bebidas.forEach(id => {
    const b = BEBIDAS.find(x => x.id === id);
    if (b) groups.push({ label: 'Bebida', value: `${b.name} — <span class="price">${b.price}</span>` });
  });
  const pg = PAGAMENTOS.find(x => x.id === S.pagamento);
  if (pg) groups.push({ label: 'Pagamento', value: pg.name });
  if (S.entrega === 'retirada') {
    groups.push({ label: 'Retirada', value: 'Planalto Petecas, Quadra W1, Casa 11' });
  } else if (S.entrega === 'delivery' && (S.rua || S.bairro)) {
    let addr = [S.rua, S.numero].filter(Boolean).join(', ');
    if (S.bairro) addr += ` — ${S.bairro}`;
    if (S.referencia.trim()) addr += `<br><small>Ref: ${S.referencia}</small>`;
    groups.push({ label: 'Delivery', value: addr });
  }

  itemsEl.innerHTML = groups.map(g =>
    `<div class="s-group"><div class="s-label">${g.label}</div><div class="s-value">${g.value}</div></div>`
  ).join('');

  /* Totals */
  const { base, extras, caldosV, bebidasV, delivery, total } = calcTotal();
  if (total > 0 && t) {
    let rows = `<div class="total-row"><span>Subtotal (${t.name})</span><span>${fmt(base)}</span></div>`;
    if (extras) { const n = S.proteinas.length - 1; rows += `<div class="total-row"><span>Proteína${n>1?'s':''} extra${n>1?'s':''} (${n})</span><span>+ ${fmt(extras)}</span></div>`; }
    if (caldosV)   rows += `<div class="total-row"><span>Caldos</span><span>+ ${fmt(caldosV)}</span></div>`;
    if (bebidasV)  rows += `<div class="total-row"><span>Bebidas</span><span>+ ${fmt(bebidasV)}</span></div>`;
    if (delivery)  rows += `<div class="total-row"><span>Taxa de entrega</span><span>+ ${fmt(delivery)}</span></div>`;
    totalsEl.innerHTML = `<div class="totals-box">${rows}<hr class="total-sep"><div class="total-final"><span class="tf-label">Total</span><span class="tf-amount">${fmt(total)}</span></div></div>`;
  } else {
    totalsEl.innerHTML = '';
  }

  /* Sep */
  sepEl?.classList.toggle('hidden', !hasAny);

  /* Action */
  if (canSubmit()) {
    actEl.innerHTML = `<a class="btn-whatsapp" href="https://wa.me/5586998201570?text=${buildMessage()}" target="_blank" rel="noopener noreferrer">
      <svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
      Pedir no WhatsApp
    </a>`;
  } else {
    actEl.innerHTML = `<div class="submit-hint">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
      <p>Selecione a massa, o molho e a forma de pagamento para liberar o pedido.</p>
    </div>`;
  }
}

/* ── BUILDERS DE UI ── */
const checkSVG = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 18 4 13"/></svg>`;

function buildOptionCards(containerId, items, stateKey, selClass, isToggle) {
  const el = document.getElementById(containerId);
  if (!el) return;
  items.forEach(item => {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'option-card';
    card.innerHTML = `
      <svg class="card-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <polyline points="20 6 9 18 4 13"/>
      </svg>
      <span class="card-name">${item.name}</span>
      ${item.desc         ? `<span class="card-desc">${item.desc}</span>`         : ''}
      ${item.ingredientes ? `<span class="card-desc">${item.ingredientes}</span>` : ''}
      ${item.price        ? `<span class="card-price">${item.price}</span>`       : ''}
    `;
    card.addEventListener('click', () => {
      if (isToggle) {
        const arr = S[stateKey];
        const idx = arr.indexOf(item.id);
        if (idx > -1) arr.splice(idx, 1); else arr.push(item.id);
        card.classList.toggle(selClass, arr.includes(item.id));
      } else {
        S[stateKey] = item.id;
        el.querySelectorAll('.option-card').forEach(c => c.classList.remove('sel-primary', 'sel-secondary'));
        card.classList.add(selClass);
      }
      render();
    });
    el.appendChild(card);
  });
}

function buildCheckGrid(containerId, items, stateKey) {
  const el = document.getElementById(containerId);
  if (!el) return;
  items.forEach(item => {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'check-card';
    card.innerHTML = `
      <div class="check-box">${checkSVG}</div>
      <span class="check-label">${item.name}</span>
    `;
    card.addEventListener('click', () => {
      const arr = S[stateKey];
      const idx = arr.indexOf(item.id);
      if (idx > -1) arr.splice(idx, 1); else arr.push(item.id);
      card.classList.toggle('selected', arr.includes(item.id));
      render();
    });
    el.appendChild(card);
  });
}

function buildPills(containerId, items, stateKey) {
  const el = document.getElementById(containerId);
  if (!el) return;
  items.forEach(item => {
    const pill = document.createElement('button');
    pill.type = 'button';
    pill.className = 'pill';
    pill.textContent = item.name;
    pill.addEventListener('click', () => {
      const arr = S[stateKey];
      const idx = arr.indexOf(item.id);
      if (idx > -1) arr.splice(idx, 1); else arr.push(item.id);
      pill.classList.toggle('selected', arr.includes(item.id));
      render();
    });
    el.appendChild(pill);
  });
}

function buildRadioGrid(containerId, items, stateKey) {
  const el = document.getElementById(containerId);
  if (!el) return;
  items.forEach(item => {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'radio-card';
    card.innerHTML = `
      <div class="radio-circle">${checkSVG}</div>
      <span class="radio-label">${item.name}</span>
    `;
    card.addEventListener('click', () => {
      S[stateKey] = item.id;
      el.querySelectorAll('.radio-card').forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      render();
    });
    el.appendChild(card);
  });
}

function buildEntrega() {
  document.querySelectorAll('.entrega-card').forEach(card => {
    card.addEventListener('click', () => {
      S.entrega = card.dataset.type;
      document.querySelectorAll('.entrega-card').forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');

      const isDelivery = S.entrega === 'delivery';
      document.getElementById('retirada-box').classList.toggle('hidden', isDelivery);
      document.getElementById('delivery-form').classList.toggle('hidden', !isDelivery);
      render();
    });
  });

  const fields = { 'f-bairro': 'bairro', 'f-rua': 'rua', 'f-numero': 'numero', 'f-ref': 'referencia' };
  Object.entries(fields).forEach(([id, key]) => {
    document.getElementById(id)?.addEventListener('input', e => { S[key] = e.target.value; render(); });
  });
}

/* ── INIT ── */
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('field-nome')?.addEventListener('input', e => { S.nome = e.target.value; render(); });
  document.getElementById('field-obs')?.addEventListener('input',  e => { S.observacoes = e.target.value; render(); });

  buildOptionCards('tamanho-grid',  TAMANHOS,  'tamanho',  'sel-primary',   false);
  buildOptionCards('macarrao-grid', MACARROES, 'macarrao', 'sel-primary',   false);
  buildOptionCards('molho-grid',    MOLHOS,    'molho',    'sel-secondary', false);
  buildOptionCards('caldos-grid',   CALDOS,    'caldos',   'sel-primary',   true);
  buildOptionCards('bebidas-grid',  BEBIDAS,   'bebidas',  'sel-primary',   true);

  buildCheckGrid('proteina-grid', PROTEINAS,  'proteinas');
  buildPills('adicional-pills',   ADICIONAIS, 'adicionais');
  buildRadioGrid('pagamento-grid', PAGAMENTOS, 'pagamento');
  buildEntrega();

  document.querySelectorAll('[data-scroll="pedido"]').forEach(el => {
    el.addEventListener('click', () => document.getElementById('pedido')?.scrollIntoView({ behavior: 'smooth' }));
  });

  render();
});
