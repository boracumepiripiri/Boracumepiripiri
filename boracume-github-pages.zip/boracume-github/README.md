# BoraCumê — Site Estático

Site de pedidos online do BoraCumê, macarrão cremoso de Piripiri, PI.

## Estrutura de pastas

```
meu-site/
 ├── index.html        → Página principal
 ├── css/
 │    └── style.css   → Todos os estilos
 ├── js/
 │    └── script.js   → Lógica do pedido e geração de mensagem WhatsApp
 ├── images/
 │    ├── pasta-real.png    → Foto do hero
 │    └── about-pasta.png  → Foto da seção Sobre
 └── README.md
```

## Como usar

Abra o `index.html` diretamente no navegador — não precisa de servidor.

## Subir no GitHub Pages

1. Crie um repositório no GitHub
2. Faça upload de **todos** os arquivos desta pasta
3. Vá em **Settings → Pages → Branch: main → / (root)**
4. Acesse `https://seu-usuario.github.io/nome-do-repo`

## Informações do negócio

- **WhatsApp:** (86) 99820-1570
- **Instagram:** @boracumepiripiri
- **Endereço de retirada:** Planalto Petecas, Quadra W1, Casa 11 — Piripiri, PI
- **Horário:** Segunda a Sábado, 12h às 20h
